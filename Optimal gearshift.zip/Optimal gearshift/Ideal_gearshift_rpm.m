format longG
% Variable Initialisation

cd=  0.3; %  drag coefficient 
den = 1.225; % density of air
area = 2.25; %frontal area
m = 2500; %Mass of car 
rr = 0.03; %rolling resistane
RR = rr.*m.*9.81; %Friction force rolling


gratio = [5 3.2 2.143 1.72 1.3140 1]; %gear ratio
Erpm = [1000 1250 1500 1750 2000  2250 2500 2750 3000 3250 3500 3750 4000 4250 4500 4750 5000]; %engine rpm
ETRQ = [450 585 702 743 772 775 780 763 741 697 663 636 616 570 522 420 360]; %engine torque
fd = 3.14; %final drive ratio
tirerad = 0.5; %tire radius
tgr = fd.*gratio; %total drive ratio
n1 = length(gratio); %lenghts to use in for loops
n2 = length(ETRQ);
n3 = length(Erpm);
n4 = length(tgr);

%calculation%
WTRQ = zeros(n1,n2); %zeros are used to reduce the computational work.
%loop to find wheel torque
 for i=1:n1
     for j=1:n2
         WTRQ(i,j)= tgr(i).*ETRQ(j);
     end
 end

Wtrac = WTRQ./tirerad; % Wheel trative force

%loop to find wheel rpm
Wrpm = zeros(n4,n3);
for i=1:n4
     for j=1:n3
         Wrpm(i,j)= Erpm(j)./tgr(i);
     end
end

wheel_velocity = (2.*3.14.* tirerad.*Wrpm)./60; %wheel velocity

%calculation to find drag force for every particular vehicle speed of wheel
%rpm for every gear
 qo = wheel_velocity.* wheel_velocity;  
drag= 0.5.*area.*den.*cd .*qo; %drag


Wtrac1 = Wtrac - drag - RR; %Wheel traction after road losses

acc = Wtrac1./m; %acceleration for every rpm


%calculation to find time between every given rpm change
dv = zeros(n4,n3);
for i=1:n3;
    if i<n3
        dv(:,i)= wheel_velocity(:,i+1)- wheel_velocity(:,i);
    end
end

 
 tad = dv./acc; %time taken to between every given rpm change
 
 % Optimal gear shift RPM
 
modshift_rpm = zeros(n4,n3); %model  rpm after gear shift which is not normalised
%loop to find mod shift rpm
%To find the RPM after gear shift i used conventional method of assuming 
%inertia of the car does not allow much rpm losses after the transmission
% So assuming the the drive shaft rpm is almost equal to the next gear
% transmission shaft rpm when the clutch locks.
% To understand better refer this link :https://www.youtube.com/watch?v=zZBqb0ZJSwU
 for i=1:n4
     for j= 1:n3
         if i<n4
             f= i+1;
            modshift_rpm(i,j)= (Erpm(1,j).*gratio(f))./ gratio(i);
            
         end   
     end           
 end
 %since we dont know engine data for every rpm we need to normalise or
 %round off to near known rpm which is done by this loop
 rpmloss= zeros(n4,n3); 
 for i= 1:n4
      for j = 1:n3
            if i< n4
                sub =  (abs(Erpm - modshift_rpm(i,j)));
                idx= find(sub==min(sub));
                rpmloss(i,j) = Erpm(idx);
     
            end
      end
     
  end
  
acc1 =zeros(n4,n3);
%acc1 is the the acceleration of car after gear shift for every rpm
%so i am comparing acc and acc 1 to decide which is better rpm to shift
 for i = 1:n4;
     for j= 1:n3;
          if i<n4
             
         
            idxe = find( Erpm == rpmloss(i,j));
            acc1(i,j)= acc(i+1,idxe);
          end
     end
 end

 for i= 1:n4;
     for j = n3:-1:1;
         if i<n4
            if acc(i,j) > acc1(i,j);
                ken = acc(i,j);
                indexg= find (acc(i,:) == ken);
                idealgear_rpm(1,i)=  Erpm(indexg); %ideal gear shift rpm
                break;
            end
         end
     end
 end
 time_eachgear = zeros(1,n4);
 distance=  zeros(n4,n3);
 distance_eachgear= zeros(1,n4);
 maxvelo_eachgear = zeros(1,n4);
 avg_velocity_eachgear = zeros(1,n4);
 avg_acceleration_eachgear= zeros(1,n4);
 
for i= 1:n4;
    
        time_eachgear(1,i) = sum(tad(i,:)); %time taken to reach the gear shift rpm for every gear
       
   
end

for i = 1:n4
    for j =1:n3
        distance(i,j) = (wheel_velocity(i,j).*tad(i,j))+ (0.5.* acc(i,j).*tad(i,j).*tad(i,j));
    end
end

for i= 1:n4;
    
        distance_eachgear(1,i) = sum(distance(i,:)); %distance covered to reach the gear shift rpm for every gear in m
       
   
end

for i= 1:n4;
     
        maxvelo_eachgear(1,i) = 3.6.*max(wheel_velocity(i,:)); % maximum velocity each gear in kmph
       
end

for i= 1:n4;
    
        avg_velocity_eachgear(1,i) = distance_eachgear(1,i)./time_eachgear(1,i); %avg velocity ( will be useful in laptime simulation)
        avg_acceleration_eachgear(1,i)= avg_velocity_eachgear(1,i)./time_eachgear(1,i); % average acceleration in m/s2
end
idealgear_rpm
time_eachgear
distance_eachgear
maxvelo_eachgear
avg_acceleration_eachgear
avgvelkmph=3.6.*avg_velocity_eachgear







         
 
